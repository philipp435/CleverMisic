# Discord Music Bot

In This tutorial Series I am explaining you how to do an advanced Music Bot in Discord, using the Distube Package

It is fast and very good!

First I will explain in several videos how to do specific Commands from skip to forward and lyrics!

After that i will cover some more backend stuff, like adding reactions, filters, how to use cookies, spotify playlist supports etc. etc.

## Installation | How to use the Bot

 **1.** Install [node.js v12+](https://nodejs.org/api/cli.html#cli_unhandled_rejections_mode) or higher

 **2.** Download this repo and unzip it    |    or git clone it

 **3.** Install all of the packages with **`npm install`**

 **4** Fill in the parameters, RIGHT in `./botconfig/config.json`!

 **5.** start the bot with **`node index.js`**

#### **NOTE:**

*If you are having errors/problems with starting delete the package.json file and do, before you install the packages `npm init`*

*MAKE SURE THAT THE BOT HAS ADMIN*

# TUTORIAL LISTS

- **1. BASICS - play - skip - stop ...** 

    - Tutorial Video: [Click Here](https://youtu.be/tF2hYHW3H4w)

    - Source Code: [Click Here]()

- **2. Handeling the Commands**

# SUPPORT ME
BY [INVITING MY PUBLIC MUSIC BOT 24/7 UPTIME!](https://discord.com/api/oauth2/authorize?client_id=742672021422342165&permissions=8&scope=bot)

This repository only exists, because of this DISCORD BOT, so make sure to invite it, so that i can keep this Repo up to date ;)

## BEST HOSTING | Bittmax.de
BITTMAX Quality is their solution.
Bittmax is our first and probably most important sponsor!

**What they are offering:**
> Quality LXC & KVM (Root) Server
> Minecraft Hosting, as well as BungeeCord Network Hosting support
> Cheap and fast Domains
> WEBHOSTING
> DISCORD, TEAMSPEAK, Setups / Music Bots
> GAME SERVER, Rust, Gary's Mod, ..

**Discord Server:**
[https://discord.gg/GgjJZCyYKD](https://discord.gg/GgjJZCyYKD)

**Website:**
[https://bittmax.de/](https://bittmax.de/])

GET **5%** OFF EVERYTHING FOR EVER!
Code: **`x10`**

## MC-Host24.de
MC-Host24.de is selling the Best Digital Hosting Services ever!
Like For games..

**What they are offering:**
> Quality LXC & KVM (Root) Server
> WORLDS BEST Minecraft Hosting,
> Cheap and fast Domains
> WEBHOSTING
> DISCORD, TEAMSPEAK, Setups / Music Bots
> GAME SERVER, Rust, Gary's Mod, ..

**Discord Server:**
[https://discord.com/invite/4dGuGXK4A4](https://discord.com/invite/4dGuGXK4A4)

**Website:**
[mc-host24.de](https://mc-host24.de/user/affiliate/3121])

# DISCORD BOTS

You can always Support me by inviting one of my **own Discord Bots**

[![Musicium Music Bot](https://cdn.discordapp.com/attachments/742446682381221938/770055673965707264/test1.png)](https://musicium.eu)
[![Milrato Multi Bot](https://cdn.discordapp.com/attachments/742446682381221938/770056826724679680/test1.png)](https://milrato.eu)

[OTHER BOTS](https://bots.musicium.eu)

[| fork my repository  |](https://github.com/user/repository/fork)
[watch this repo  |](https://github.com/user/repository/subscription)
[create issue |](https://github.com/user/repository/issues/new)

*Both bots are still in Development, and will always be in development, this means always uptodate and always online and always improving!*
